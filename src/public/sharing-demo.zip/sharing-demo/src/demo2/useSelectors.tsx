import { useReducer, useEffect, useRef } from "react";
import {  globalStore, type GlobalState } from "./globalStore";

export const useSelectorVersion1 = () => {
  const [, forceRender] = useReducer((s) => s + 1, 0);
  useEffect(() => {
    const unSubscribe = globalStore.subscribe(forceRender);
    return unSubscribe;
  }, []);
};

export const useSelectorVersion2 = (selector: (state: GlobalState) => GlobalState[keyof GlobalState]) => {
  const [, forceRender] = useReducer((s) => s + 1, 0);
  useEffect(() => {
    const unSubscribe = globalStore.subscribe(forceRender);
    return unSubscribe;
  }, []);

  return selector(globalStore.state);
};

export const useSelectorVersion3 = <T,>(selector: (state: GlobalState) => T) => {
  const [, forceRender] = useReducer((s) => s + 1, 0);

  const latestSelected = useRef<T>(selector(globalStore.state));
  useEffect(() => {
    // 外部store发生变化时的 callback
    const checkForUpdates = () => {
      // 执行一次 selector 函数，拿到最新的值
      const newSelected = selector(globalStore.state);
      // 新旧值进行对比，发生改变就通知 react 进行 render
      if (newSelected !== latestSelected.current) {
        latestSelected.current = newSelected;
        forceRender();
      }
    };
    // 订阅外部store
    const unSubscribe = globalStore.subscribe(checkForUpdates);
    return unSubscribe;
  }, []);

  return selector(globalStore.state);
};