import { generateWord, getRandomHexColor } from "../utils";

export type GlobalState = {
    backgroundColor?: string;
    time?: string;
    word?: string;
};
type Listener = () => void;

const globalState: GlobalState = {
    backgroundColor: getRandomHexColor(),
    time: new Date().toISOString(),
    word: generateWord(),
};

export const globalStore = {
    state: globalState,
    listeners: [] as Listener[],
    subscribe: (callback: Listener) => {
        globalStore.listeners.push(callback);

        // 返回取消订阅函数
        return () => {
            globalStore.listeners = globalStore.listeners.filter((l) => l !== callback);
        };
    },
    notify: () => {
        globalStore.listeners.forEach((l) => l());
    },
    set: (modifyState: () => void) => {
        modifyState();
        globalStore.notify();
    },
};