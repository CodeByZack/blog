import { Button, Card, Code, Grid, Text } from "@geist-ui/core";
import { RenderCounter } from "../hooks/useRenderCount";
import { generateWord, getRandomHexColor } from "../utils";
import { useForceRender } from "../hooks/useForceRender";
import { useEffect } from "react";
import { useSelectorVersion1, useSelectorVersion2, useSelectorVersion3 } from "./useSelectors";
import { globalStore } from "./globalStore";

export const Demo2 = () => {
  return (
    <Card style={{ position: "relative" }}>
      <Grid.Container gap={1.5}>
        <Grid xs={24}>
          <ShowGlobalStoreData />
        </Grid>
        <Grid xs={8}>
          <Timer />
        </Grid>
        <Grid xs={8}>
          <Color />
        </Grid>
        <Grid xs={8}>
          <Word />
        </Grid>
      </Grid.Container>
    </Card>
  );
};

let timerId: number | undefined = undefined;

const startTimer = () => {
  if (timerId) {
    clearInterval(timerId);
  }
  const id = setInterval(() => {
    // step1
    // globalState.time = new Date().toISOString();
    // step2
    globalStore.set(() => {
      globalStore.state.time = new Date().toISOString();
    });
    console.log(globalStore.state.time);
  }, 1000);
  timerId = id;
};

const closeTimer = () => {
  if (timerId) {
    clearInterval(timerId);
  }
  timerId = undefined;
};

const ShowGlobalStoreData = () => {
  const forceRender = useForceRender();
  useEffect(() => {
    const unSubscribe = globalStore.subscribe(forceRender);
    return unSubscribe;
  }, []);

  const updateColor = () => {
    // step1
    // globalState.backgroundColor = getRandomHexColor();
    // forceRender();

    // step2
    globalStore.set(() => {
      globalStore.state.backgroundColor = getRandomHexColor();
    });

    console.log(globalStore.state.backgroundColor);
  };

  const updateWord = () => {
    // step1
    // globalState.word = generateWord();
    // forceRender();

    // step2
    globalStore.set(() => {
      globalStore.state.word = generateWord();
    });
    console.log(globalStore.state.word);
  };

  return (
    <Card width="100%" style={{ position: "relative", backgroundColor: globalStore.state.backgroundColor }}>
      <Text h3>GlobalStore</Text>
      <RenderCounter name="GlobalStoreData" />
      <Code block>{JSON.stringify(globalStore.state, null, 2)}</Code>
      <Grid.Container gap={2} justify="center">
        <Grid xs={6}>
          <Button
            onClick={() => {
              if (timerId) {
                closeTimer();
              } else {
                startTimer();
              }
            }}
            auto
            placeholder={undefined}
            onPointerEnterCapture={undefined}
            onPointerLeaveCapture={undefined}
          >
            timer
          </Button>
        </Grid>
        <Grid xs={6}>
          <Button onClick={updateColor} auto placeholder={undefined} onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined}>
            color
          </Button>
        </Grid>
        <Grid xs={6}>
          <Button onClick={updateWord} auto placeholder={undefined} onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined}>
            word
          </Button>
        </Grid>
      </Grid.Container>
    </Card>
  );
};

const Timer = () => {
  useSelectorVersion1();
  const { time } = globalStore.state;
  return (
    <Card width="100%" style={{ position: "relative" }}>
      <Text h5>Timer</Text>
      <Text>{new Date(time!).toLocaleString()}</Text>
      <RenderCounter name="Timer" />
    </Card>
  );
};

const Color = () => {
  //   useSelectorVersion1();
  //   const { backgroundColor } = globalState;
  const backgroundColor = useSelectorVersion2((s) => s.backgroundColor);

  return (
    <Card width="100%" style={{ position: "relative", backgroundColor }}>
      <Text h5>Color</Text>
      <Text>{backgroundColor}</Text>
      <RenderCounter name="Color" />
    </Card>
  );
};

const Word = () => {
  //   const { word } = globalState;
  const word = useSelectorVersion3((s) => s.word);

  return (
    <Card width="100%" style={{ position: "relative" }}>
      <Text h5>Word</Text>
      <Text>{word}</Text>
      <RenderCounter name="Word" />
    </Card>
  );
};
