import "./App.css";
import { Demo1 } from "./demo1/demo1";
import { GeistProvider, CssBaseline } from "@geist-ui/core";
import { Demo2 } from "./demo2/demo2";
import { Demo3 } from "./demo3/demo3";

function App() {
  return (
    <GeistProvider>
      <CssBaseline />
      {/* <Demo1 /> */}
      {/* <Demo2 /> */}
      <Demo3/>
    </GeistProvider>
  );
}

export default App;
