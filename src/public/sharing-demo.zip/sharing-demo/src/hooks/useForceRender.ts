import { useCallback, useState } from "react";

export const useForceRender = () => {
    // const [, forceRender] = useReducer((s) => s + 1, 0);
    const [, set] = useState(0);
    const forceRender = useCallback(() => {
        set((x) => x + 1);
    },[]);
    return forceRender;
};