import { useRef } from "react";

export const useRenderCounter = (name?:string) => {
  const renderCounter = useRef(0);
  renderCounter.current++;
  console.log(`${name} rendered ${renderCounter.current}`);  
  return renderCounter;
};

export const RenderCounter = ({ name }: { name : string}) => {
  const renderCounter = useRenderCounter(name);
  return <span className="topRight">{renderCounter.current}</span>;
};
