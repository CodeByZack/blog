export const getRandomHexColor = () => {
    // 生成一个较为柔和的颜色
    const r = Math.floor(Math.random() * 128 + 64); // 红色部分：值在 64 - 191 之间
    const g = Math.floor(Math.random() * 128 + 64); // 绿色部分：值在 64 - 191 之间
    const b = Math.floor(Math.random() * 128 + 64); // 蓝色部分：值在 64 - 191 之间
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
};


export const generateWord = () => {
    const adjectives = ['quick', 'happy', 'bright', 'cool', 'silent'];
    const nouns = ['fox', 'river', 'cloud', 'stone', 'tree'];

    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const noun = nouns[Math.floor(Math.random() * nouns.length)];

    return adj + '-' + noun;
}
