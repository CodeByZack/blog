import { Button, Card, Grid, Spacer, Text } from "@geist-ui/core";
import { RenderCounter } from "../hooks/useRenderCount";
import { memo } from "react";
import { useForceRender } from "../hooks/useForceRender";
import { getRandomHexColor } from "../utils";

const globalState: { backgroundColor?: string } = { backgroundColor: undefined };
const Parent = () => {
  // 1. The parent render will force a child render whether the props change or not
  const forceRender = useForceRender();

  const children = ["Child-A", "Child-B", "Child-C"] as const;
  return (
    <Card style={{ position: "relative" }}>
      <Text>Parent</Text>
      <Button auto onClick={() => forceRender()} placeholder="" onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined}>
        render parent
      </Button>
      <Spacer />
      <Grid.Container gap={1.5}>
        {children.map((type) => (
          <Grid xs={8} key={type}>
            <ChildX type={type} />
          </Grid>
        ))}
        <Grid xs={16}>
          <ChildD backgroundColor={globalState.backgroundColor} />
        </Grid>
        <Grid xs={8}>
          <ChildE />
        </Grid>
      </Grid.Container>

      <RenderCounter name="Parent" />
    </Card>
  );
};

const ChildD = memo((props: { backgroundColor?: string }) => {
  const { backgroundColor } = props;
  const forceRender = useForceRender();
  return (
    <Card width="100%" style={{ position: "relative", backgroundColor }}>
      <Text h4 style={{ textTransform: "uppercase" }}>
        Child-D
      </Text>
      <Button auto onClick={() => forceRender()} placeholder="" onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined}>
        render
      </Button>
      <Spacer />
      <Button
        auto
        onClick={() => {
          // 虽然改变了传递给组件的props，但并不会触发 Child-D 的 rerender
          globalState.backgroundColor = getRandomHexColor();

          const el = document.querySelector("#globalStore")! as HTMLDivElement;
          el.innerHTML = `globalState is ${JSON.stringify(globalState)}`;
          if (globalState.backgroundColor) {
            el.style.backgroundColor = globalState.backgroundColor;
            el.style.color = "#ffffff";
          }
        }}
        placeholder=""
        onPointerEnterCapture={undefined}
        onPointerLeaveCapture={undefined}
      >
        change external state
      </Button>

      <RenderCounter name="Child-D" />
    </Card>
  );
});

const ChildE = () => {
  const forceRender = useForceRender();
  return (
    <Card width="100%" style={{ position: "relative" }}>
      <Text h4 style={{ textTransform: "uppercase" }}>
        ChildE
      </Text>
      <Button auto onClick={() => forceRender()} placeholder="" onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined}>
        render
      </Button>
      <RenderCounter name={"ChildE"} />
      <Spacer />
      <Grid.Container gap={1.5}>
        <Grid xs={12}>
          <ChildF />
        </Grid>
        <Grid xs={12}>
          <ChildG />
        </Grid>
      </Grid.Container>
    </Card>
  );
};

const ChildF = () => {
  const forceRender = useForceRender();
  return (
    <Card width="100%" style={{ position: "relative" }}>
      <Text h4 style={{ textTransform: "uppercase" }}>
        ChildF
      </Text>
      <Button auto onClick={() => forceRender()} placeholder="" onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined}>
        render
      </Button>
      <RenderCounter name={"ChildF"} />
    </Card>
  );
};

const ChildG = () => {
  const forceRender = useForceRender();
  return (
    <Card width="100%" style={{ position: "relative" }}>
      <Text h4 style={{ textTransform: "uppercase" }}>
        ChildG
      </Text>
      <Button auto onClick={() => forceRender()} placeholder="" onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined}>
        render
      </Button>
      <RenderCounter name={"ChildG"} />
    </Card>
  );
};

const ChildX = ({ type }: { type: string }) => {
  const forceRender = useForceRender();

  return (
    <Card width="100%" style={{ position: "relative" }}>
      <Text h4 style={{ textTransform: "uppercase" }}>
        {type}
      </Text>
      <Button auto onClick={() => forceRender()} placeholder="" onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined}>
        render
      </Button>
      <RenderCounter name={type} />
    </Card>
  );
};

export const Demo1 = () => {
  return <Parent />;
};
