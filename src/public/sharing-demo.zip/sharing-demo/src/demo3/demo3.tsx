import { Button, Card, Input, Text } from "@geist-ui/core";
import { useState, startTransition, useRef, useEffect, useSyncExternalStore } from "react";

// let externalState = { counter: 0 };

const useExternalStore = () => {
  const value = useSyncExternalStore(()=>{},()=>input.value);
  return value;
  // return input.value;
}

const SlowComponent = () => {
  const externalStore = useExternalStore();
  const now = performance.now();
  while (performance.now() - now < 100) {
    // do nothing
  }
  return <Text>ExternalStore: {externalStore}</Text>;
};

export const Demo3 = () => {
  const [show, setShow] = useState(false);
  // const timerIdRef = useRef<number>(undefined);

  // useEffect(() => {
  //   timerIdRef.current = setInterval(() => {
  //     externalState.counter++;
  //     console.log(externalState.counter);
  //   }, 50);
  //   return () => {
  //     clearInterval(timerIdRef.current);
  //   };
  // }, []);

  return (
    <Card>
      <Button
        onClick={() => {
          // setShow(!show);
          startTransition(() => {
            setShow(!show);
          });
        }}
        placeholder={undefined}
        onPointerEnterCapture={undefined}
        onPointerLeaveCapture={undefined}
      >
        toggle content
      </Button>
      {show && (
        <>
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
          <SlowComponent />
        </>
      )}
    </Card>
  );
};
